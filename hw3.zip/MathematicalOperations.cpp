﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#include "MathematicalOperations.h"

namespace OOP_Hw3 {
	SharedPtr<Function> operator+(SharedPtr<Function> f1, SharedPtr<Function> f2) {
		SharedPtr<Function> f3=new add(f1,f2);
		return f3;


	}

	SharedPtr<Function> operator-(SharedPtr<Function> f1, SharedPtr<Function> f2) {
		SharedPtr<Function> f3 = new sub(f1,f2);
		return f3;
	}
	SharedPtr<Function> operator*(SharedPtr<Function> f1, SharedPtr<Function> f2) {
		SharedPtr<Function> f3 = new multi(f1,f2);
		return f3;
	}
	SharedPtr<Function> operator/(SharedPtr<Function> f1, SharedPtr<Function> f2) {
		SharedPtr<Function> f3 = new div(f1, f2);
		return f3;
	}

	SharedPtr<Function> var(const std::string& variableName) {
		SharedPtr<Function> f3 = new varr(variableName);
		return f3;
	}
	SharedPtr<Function> cnst(double num) {
		SharedPtr<Function> f3 = new constant(num);
		return f3;
	}
}