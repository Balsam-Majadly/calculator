﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#include"multi.h"
namespace OOP_Hw3 {
	
	double multi::Evaluate(const map<string, double>& variables) const {
		double x = this->getLift()->Evaluate(variables);
		double y = this->getRight()->Evaluate(variables);
		double z = y*x;
		return  z;
	}


	multi::multi(SharedPtr<Function> f1, SharedPtr<Function> f2) :Function(f1, f2) {


		this->setstring("*");
		this->setflag(1); // the node is mathematical operation

	}

	SharedPtr<Function> multi::DeriveBy(const string& variable) const {
		SharedPtr<Function> x = this->getRight()->DeriveBy(variable);
		SharedPtr<Function> y = this->getLift()->DeriveBy(variable);
		SharedPtr<Function> z = this->getRight();
		SharedPtr<Function> w = this->getLift();
		SharedPtr<Function> f3 = new multi(x, w);
		SharedPtr<Function> f4 = new multi(y, z);
		SharedPtr<Function> f5 = new add(f3, f4);

		return f5;
	}
}