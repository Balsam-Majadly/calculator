﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#include"sub.h"
namespace OOP_Hw3 {
	double sub::Evaluate(const map<string, double>& variables) const {
		return  this->getRight()->Evaluate(variables) - this->getLift()->Evaluate(variables);
	}

	sub::sub(SharedPtr<Function> f1, SharedPtr<Function> f2) :Function(f1, f2) {

		this->setstring("-");
		this->setflag(1);// the node is mathematical operation

	}

	SharedPtr<Function> sub::DeriveBy(const string& variable) const {
		SharedPtr<Function> x = this->getRight()->DeriveBy(variable);
		SharedPtr<Function> y = this->getLift()->DeriveBy(variable);
		SharedPtr<Function> f3 = new sub(x, y);


		return f3;
	}



}