﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#include"var.h"
namespace OOP_Hw3 {
	double varr:: Evaluate(const map<string, double>& variables) const {
		map<string, double>::iterator iter;
		string name = this->getName();
		double x = variables.find(name)->second;
		return x ;
	}

	varr::varr(const std::string& variableName) {
		
		this->setstring(variableName);
		this->setflag(3);// the node is variable

	}
	SharedPtr<Function> varr::DeriveBy(const string& variable) const {
		if (this->getName() == variable) {
			SharedPtr<Function> f3 = new constant(1);

			return f3;
		}
		SharedPtr<Function> f2 = new constant(0);

		return f2;


	}

}