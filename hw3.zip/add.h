﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#pragma once
#include"Function.h"

namespace OOP_Hw3 {
	//SharedPtr<Function> f1;
	//SharedPtr<Function> f2;
	class add :public Function {
	public:
		double Evaluate(const map<string, double>& variables) const;

		add(SharedPtr<Function> f11, SharedPtr<Function> f22);

		SharedPtr<Function> DeriveBy(const string& variable) const;

		
	};
}