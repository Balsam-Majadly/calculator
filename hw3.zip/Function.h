﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#pragma once
#include <string>
#include <iostream> 
#include <iterator> 
#include <map>
#include <list>
#include "SharedPtr.h"
using std::string;
using std::map;
using std::list;
namespace OOP_Hw3
{
	class Function
	{
	public:
		Function(SharedPtr<Function> f11, SharedPtr<Function> f22);
		Function();
		void setright(SharedPtr<Function> f1);
		void setleft(SharedPtr<Function> f1);
		void setVar(list<string> f1);
		void setkey(double f1);
		void setstring(string f1);
		void setflag(int f1);
		double getKey()const;
		SharedPtr<Function> getRight()const;
		SharedPtr<Function> getLift()const;
		string getName()const;
		int getFlag()const;
		list<string> getVar()const;
	
		virtual double Evaluate(const map<string, double>& variables) const=0;
		 list<string> Variables() const;
		 virtual SharedPtr<Function> DeriveBy(const string& variable) const=0;
		 map<string, map<string, SharedPtr<Function>>> Hessian() const;
		
	private:
		double Key;
		int flag; // if the node is constant or variable or mathematical operations
		string name; // the name of variable or mathematical operations
		SharedPtr<Function>  Left;//left subtree
		SharedPtr<Function>  Right;
		list<string> bvar; // variabels
		


	};


}
