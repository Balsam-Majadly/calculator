﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#pragma once
#include"Function.h"
#include"add.h"
namespace OOP_Hw3 {
	class multi :public Function {
	public:
		double Evaluate(const map<string, double>& variables) const;


		multi(SharedPtr<Function> f1, SharedPtr<Function> f2);

		SharedPtr<Function> DeriveBy(const string& variable) const;
	};
}