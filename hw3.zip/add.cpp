﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#include"add.h"
namespace OOP_Hw3 {
	double add::Evaluate(const map<string, double>& variables) const {
		double x = this->getRight()->Evaluate(variables);
		return x + this->getLift()->Evaluate(variables);
	}

	add::add(SharedPtr<Function> f11, SharedPtr<Function> f22) :Function(f11, f22) {
		this->setstring("+");
		this->setflag(1); // the node is a mathematical operation
	}

	SharedPtr<Function> add::DeriveBy(const string& variable) const {
		SharedPtr<Function> x = this->getRight()->DeriveBy(variable);
		SharedPtr<Function> y = this->getLift()->DeriveBy(variable);
		SharedPtr<Function> f3 = new add(x, y);
		return f3;
	}


}