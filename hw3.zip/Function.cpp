﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#include "Function.h"
namespace OOP_Hw3 {
	void Function::setright(SharedPtr<Function> f1) {
		Right = f1;

	}
	void Function::setleft(SharedPtr<Function> f1) {
		Left = f1;
	}
	void Function::setkey(double f1) {
		Key = f1;

	}
	void Function::setstring(string f1) {
		name = f1;
	}

	void Function::setflag(int f1) {
		flag = f1;
	}

	void Function::setVar(list<string> f1) {
		bvar = f1;
	}

	list<string> Function:: Variables() const{
		list<string>::iterator iter;
		string x = this->getName();
		list<string> listt ;
		if (this->getFlag() == 3) { // if the node is variable
			listt.push_back(x);
			return listt;
			}
		
		if (this->getFlag() == 1) { // if the node is mathematical operation
			listt=Left->Variables();
			list<string> list2 = Right->Variables();
			 list <string> :: iterator it; 
			 for (it = list2.begin(); it != list2.end(); ++it) { // link the variable list of the left subtree with rigth subtree
				 iter = find(listt.begin(), listt.end(), *it);
				 if (iter == listt.end()) {
					 listt.push_back(*it);
				 }
			 }


		}
		
		return listt;

	}

	SharedPtr<Function> Function::getRight()const {
		
		return Right;

	}

	int Function::getFlag()const {
		return flag;
	}
	list<string> Function::getVar()const {
		return bvar;

	}
	SharedPtr<Function> Function::getLift()const {
		return Left;
	}

	double Function::getKey()const {
		return Key;
	}

	string Function::getName()const {

		return name;
	}
	Function::Function(SharedPtr<Function> f11, SharedPtr<Function> f2): Right( f11),	Left ( f2){
	
	}
 Function::Function():Right(NULL), Left(NULL) {
 
 }

 map<string, map<string, SharedPtr<Function>>>Function::Hessian() const {
	 list<string>::iterator iter1, iter2;
	 list<string> list = this->Variables();
	 string x, y;
	 map<string, map<string, SharedPtr<Function>>> matrix;
	 for (iter1 = list.begin(); iter1 != list.end(); ++iter1) {
		 for (iter2 = list.begin(); iter2 != list.end(); ++iter2) {
			 x = *iter1;
			 y = *iter2;
			 matrix[x][y] = this->DeriveBy(x)->DeriveBy(y);
		

		 }

	 }
	 return matrix;
		 
 }


}