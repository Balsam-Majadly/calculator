﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#include"div.h"
namespace OOP_Hw3 {
	double div::Evaluate(const map<string, double>& variables) const {
		return  this->getRight()->Evaluate(variables) / this->getLift()->Evaluate(variables);
	}

	div::div(SharedPtr<Function> f1, SharedPtr<Function> f2) : Function(f1, f2) {
		
		this->setstring("/");
		this->setflag(1);// the node is mathemaical operation

	}

	SharedPtr<Function> div::DeriveBy(const string& variable) const {
		SharedPtr<Function> x = this->getRight()->DeriveBy(variable);
		SharedPtr<Function> y = this->getLift()->DeriveBy(variable);
		SharedPtr<Function> z = this->getRight();
		SharedPtr<Function> w = this->getLift();
		SharedPtr<Function> f3 = new multi(x, w);
		SharedPtr<Function> f4 = new multi(y, z);
		SharedPtr<Function> f5 = new sub(f3, f4);
		SharedPtr<Function> f6 = new multi(w, w);
		SharedPtr<Function> f7 = new div(f5, f6);
		return f7;
	}


}