﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#pragma once

#include<iostream>

template<class T>
class  SharedPtr
{
	T* sharedPtr;
	int* refCount;
	int x = 0;

public:
	SharedPtr(T* ptr)
	{
		sharedPtr = ptr;
		refCount = new int(1);
	}

	SharedPtr()
	{
		sharedPtr = NULL;
		refCount = new int(0);
	}
	~SharedPtr()
	{
		--(*refCount);
		if (*refCount <= 0)
		{
			delete sharedPtr;
			delete refCount;
		}
	}

	T* operator->() { return sharedPtr; }
	const T* operator->() const { return sharedPtr; }
	T& operator*() { return *sharedPtr; }
	const T& operator*() const { return *sharedPtr; }

	SharedPtr<T>& operator=(const SharedPtr<T>& ptr);
	SharedPtr(const SharedPtr<T>& ptr);
};

template <class T>
SharedPtr<T>& SharedPtr<T>::operator=(const SharedPtr<T>& ptr)
{
	if (this != &ptr)

	{
	/*	if (x == 1) {
			this->sharedPtr = ptr.sharedPtr;
			this->refCount = ptr.refCount;
			++(*(ptr.refCount));
		  }*/
		--*(this->refCount);
		if (*(this->refCount) <= 0)
		{
			delete (this->sharedPtr);
			delete (this->refCount);
		}


		this->sharedPtr = ptr.sharedPtr;
		this->refCount = ptr.refCount;
		++(*(ptr.refCount));
	}

	return *this;
}

template <class T>
SharedPtr<T>::SharedPtr(const SharedPtr<T>& ptr)
{
	this->sharedPtr = ptr.sharedPtr;
	this->refCount = ptr.refCount;
	++(*(ptr.refCount));
}

