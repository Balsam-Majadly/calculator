﻿/*/ 209393628- Balsam Majadly- balsam.mm5b@gmail.com
//314628124 - mariam Abbas- mariam220298@gmail.com‏‏*/

#include"constant.h"
namespace OOP_Hw3 {

	double constant::Evaluate(const map<string, double>& variables) const {

		double x = this->getKey();
		return x;
	}
	constant::constant(double num) {
		this->setstring("const");
		this->setkey(num);
		this->setflag(2); // the node is constant

	}

	SharedPtr<Function> constant::DeriveBy(const string& variable) const {

		SharedPtr<Function> f3 = new constant(0);

		return f3;
	}
}